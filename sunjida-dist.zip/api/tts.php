<?php
/**
 * SalesDaddy TTS API — Bengali-optimized text-to-speech
 *
 * POST /api/tts.php
 * Body: { "text": "...", "voice": "alloy", "speed": 1.0 }
 * Returns: audio/mpeg stream
 *
 * Uses OpenAI TTS API via Lovable gateway for high-quality Bengali voices.
 */

require_once __DIR__ . '/config.php';
corsHeaders();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'POST required'], 405);
}

$input = json_decode(file_get_contents('php://input'), true);
$text = trim($input['text'] ?? '');
if (!$text) {
    jsonResponse(['error' => 'text is required'], 400);
}

// Truncate very long text for TTS (TTS limits)
if (mb_strlen($text) > 4000) {
    $text = mb_substr($text, 0, 4000);
}

// Detect if text is Bengali and set appropriate voice/speed
$isBengali = preg_match('/[\x{0980}-\x{09FF}]/u', $text);
$voice = $input['voice'] ?? ($isBengali ? 'nova' : 'alloy');
$speed = $input['speed'] ?? 1.0;

// OpenAI TTS API (same key the Supabase agent uses for generateSpeech)
$ch = curl_init('https://api.openai.com/v1/audio/speech');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => false,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode([
        'model'  => 'tts-1-hd',
        'input'  => $text,
        'voice'  => $voice,
        'speed'  => $speed,
        'response_format' => 'mp3',
    ]),
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . AI_API_KEY,
    ],
    CURLOPT_TIMEOUT        => 30,
]);

// Stream the audio response
header('Content-Type: audio/mpeg');
header('Cache-Control: no-cache');
header('X-Accel-Buffering: no');

curl_exec($ch);

if (curl_errno($ch)) {
    http_response_code(502);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'TTS error: ' . curl_error($ch)]);
}
curl_close($ch);
