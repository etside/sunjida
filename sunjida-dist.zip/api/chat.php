<?php
/**
 * SalesDaddy Chat API — PHP Fallback
 *
 * When Supabase is unavailable, this endpoint:
 * 1. Looks up business settings from local MySQL
 * 2. Builds a system prompt
 * 3. Calls the AI gateway directly
 * 4. Streams the response as SSE (same format as Supabase agent-chat)
 *
 * POST /api/chat.php
 * Body: { "businessId": "...", "messages": [{ "role": "user", "content": "..." }], "conversationId": "..." }
 *
 * GET /api/chat.php?businessId=...  →  Bootstrap (greeting + enabled flag)
 */

require_once __DIR__ . '/config.php';
corsHeaders();

$method = $_SERVER['REQUEST_METHOD'];

// ── GET: Bootstrap (greeting + enabled) ───────────────────────────────
if ($method === 'GET') {
    $businessId = $_GET['businessId'] ?? null;

    try {
        $db = getDB();
        $settings = getSettings($db, $businessId);
        jsonResponse([
            'business_name' => $settings['business_name'] ?? 'SalesDaddy',
            'greeting_en'   => $settings['greeting_en'] ?? 'Hi! How can I help you today?',
            'greeting_bn'   => $settings['greeting_bn'] ?? 'হ্যালো! আমি কীভাবে আপনাকে সাহায্য করতে পারি?',
            'is_enabled'    => (bool)($settings['is_enabled'] ?? 1),
        ]);
    } catch (Throwable $e) {
        jsonResponse(['error' => $e->getMessage()], 500);
    }
}

// ── POST: Chat ────────────────────────────────────────────────────────
if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $businessId    = $input['businessId'] ?? null;
    $messages      = $input['messages'] ?? [];
    $conversationId = $input['conversationId'] ?? null;

    if (empty($messages)) {
        jsonResponse(['error' => 'messages is required'], 400);
    }

    // Only keep last 20 messages (matches Supabase behavior)
    $messages = array_slice($messages, -20);

    try {
        $db = getDB();
        $settings = getSettings($db, $businessId);

        if (empty($settings['is_enabled'])) {
            jsonResponse(['error' => 'The assistant is currently turned off.'], 503);
        }

        // Build system prompt
        $system = buildSystemPrompt($settings);

        // Build conversation
        $convo = array_merge([['role' => 'system', 'content' => $system]], $messages);

        // Call AI gateway
        $payload = json_encode([
            'model'    => $settings['model'] ?? AI_MODEL,
            'messages' => $convo,
            'stream'   => true,
        ]);

        $ch = curl_init(AI_GATEWAY_URL);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . AI_API_KEY,
            ],
            CURLOPT_TIMEOUT        => 60,
        ]);

        $reply = '';
        curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($ch, $chunk) use (&$reply) {
            $lines = explode("\n", $chunk);
            foreach ($lines as $line) {
                $line = trim($line);
                if (str_starts_with($line, 'data: ')) {
                    $data = substr($line, 6);
                    if ($data === '[DONE]') break;
                    $json = json_decode($data, true);
                    $delta = $json['choices'][0]['delta']['content'] ?? '';
                    $reply .= $delta;
                }
            }
            return strlen($chunk);
        });
        curl_exec($ch);

        if (curl_errno($ch)) {
            jsonResponse(['error' => 'AI gateway error: ' . curl_error($ch)], 502);
        }
        curl_close($ch);

        if (!$reply) $reply = 'Sorry, I could not put together a reply. Could you try rephrasing?';

        // Store messages in local DB
        storeMessages($db, $conversationId, $messages, $reply);

        sseResponse($reply, $conversationId);

    } catch (Throwable $e) {
        jsonResponse(['error' => $e->getMessage()], 500);
    }
}

// ── Database helpers ──────────────────────────────────────────────────

function getSettings(PDO $db, ?string $businessId): array {
    if ($businessId) {
        $stmt = $db->prepare('SELECT * FROM businesses WHERE id = ? LIMIT 1');
        $stmt->execute([$businessId]);
        $row = $stmt->fetch();
        if (!$row) {
            return [
                'business_name' => 'SalesDaddy',
                'greeting_en'   => 'Hi! How can I help you today?',
                'greeting_bn'   => 'হ্যালো! আমি কীভাবে আপনাকে সাহায্য করতে পারি?',
                'is_enabled'    => 1,
                'model'         => AI_MODEL,
            ];
        }
        return $row;
    }
    // Default settings (no specific business)
    return [
        'business_name' => 'SalesDaddy',
        'greeting_en'   => 'Hi! How can I help you today?',
        'greeting_bn'   => 'হ্যালো! আমি কীভাবে আপনাকে সাহায্য করতে পারি?',
        'is_enabled'    => 1,
        'model'         => AI_MODEL,
    ];
}

function buildSystemPrompt(array $settings): string {
    $name = $settings['business_name'] ?? 'SalesDaddy';
    $products = '';

    // Try to load product catalog from DB
    try {
        $db = getDB();
        $stmt = $db->query('SELECT name, description, price, stock FROM products LIMIT 50');
        $rows = $stmt->fetchAll();
        if ($rows) {
            $lines = [];
            foreach ($rows as $r) {
                $line = "- {$r['name']}";
                if (!empty($r['description'])) $line .= ": {$r['description']}";
                if (!empty($r['price'])) $line .= " (৳{$r['price']})";
                if (!empty($r['stock'])) $line .= " [Stock: {$r['stock']}]";
                $lines[] = $line;
            }
            $products = "\n\nProduct Catalog:\n" . implode("\n", $lines);
        }
    } catch (Throwable $e) {
        // Products table may not exist yet — that's fine
    }

    return "You are SalesDaddy, a friendly and knowledgeable sales assistant for {$name}. Your job is to help customers find products, answer questions, take orders, and provide support.

CRITICAL RULES:
- Always respond in the SAME LANGUAGE the customer uses. If they write in Bangla (বাংলা), respond in Bangla. If they write in English, respond in English. Never mix languages in one reply.
- For Bangla replies: Use natural, conversational Bangla. Write as a native Bangla speaker would. Use simple, polite Bangla suitable for phone/chat sales.
- Keep responses concise and helpful — aim for 1-3 sentences unless the customer asks for details.
- If recommending products, mention the price in Bangladeshi Taka (৳) and include stock availability.
- Be warm, polite, and professional. Use greetings like "আসসালামু আলাইকুম" or "নমস্কার" when appropriate.
- If you don't know something, say so honestly and offer to connect them with a human.
- Never make up product information. Only reference products from the catalog below.
{$products}";
}

function storeMessages(PDO $db, ?string $conversationId, array $userMessages, string $reply): void {
    try {
        // Create tables if they don't exist
        $db->exec("CREATE TABLE IF NOT EXISTS conversations (
            id VARCHAR(36) PRIMARY KEY,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            conversation_id VARCHAR(36),
            role VARCHAR(20),
            content TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_conv (conversation_id)
        )");

        if (!$conversationId) {
            $conversationId = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                mt_rand(0, 0xffff), mt_rand(0, 0xffff),
                mt_rand(0, 0xffff), mt_rand(0, 0x0fff) | 0x4000,
                mt_rand(0, 0x3fff) | 0x8000,
                mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
            );
            $db->prepare('INSERT IGNORE INTO conversations (id) VALUES (?)')->execute([$conversationId]);
        }

        $stmt = $db->prepare('INSERT INTO messages (conversation_id, role, content) VALUES (?, ?, ?)');
        $lastUser = end($userMessages);
        if ($lastUser) {
            $stmt->execute([$conversationId, 'user', $lastUser['content'] ?? '']);
        }
        $stmt->execute([$conversationId, 'assistant', $reply]);
    } catch (Throwable $e) {
        // Non-critical — log but don't fail the response
        error_log('[SalesDaddy] storeMessages error: ' . $e->getMessage());
    }
}
