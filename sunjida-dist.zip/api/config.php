<?php
/**
 * SalesDaddy PHP Fallback Backend
 * Used when Supabase is unavailable on cPanel shared hosting.
 * Connects to local MySQL and proxies to the AI gateway.
 */

// ── Database credentials (cPanel shared hosting) ──────────────────────
define('DB_HOST',   'localhost');
define('DB_NAME',   'torquest_Sales');
define('DB_USER',   'torquest_daddy');
define('DB_PASS',   'ER?b~SJAqPsYShy+');

// ── AI Gateway (same one Supabase edge functions use) ─────────────────
define('AI_GATEWAY_URL', 'https://ai.gateway.lovable.dev/v1/chat/completions');
define('AI_API_KEY',     'lvk_1w4233_44532n3g120n2p700v38322z55231i3g3o');
define('AI_MODEL',       'google/gemini-2.0-flash');

// ── Supabase (for reference / pass-through) ───────────────────────────
define('SUPABASE_URL',          'https://yplgzmxzrslofnuagfaz.supabase.co');
define('SUPABASE_PUBLISHABLE_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlwbGd6bXh6cnNsb2ZudWFnZmF6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjkxOTgxNTgsImV4cCI6MjA4NDc3NDE1OH0.i9RxJRB2VE87Qqvvgu27OVPqpFUfdat1DLYI6j_TxIs');

// ── Helpers ───────────────────────────────────────────────────────────
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

function corsHeaders(): void {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

function jsonResponse(mixed $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function sseResponse(string $text, ?string $conversationId = null): void {
    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('X-Accel-Buffering: no');
    header('Access-Control-Expose-Headers: X-Conversation-Id');
    if ($conversationId) {
        header('X-Conversation-Id: ' . $conversationId);
    }

    $chunks = preg_split('/\S+\s*/', $text, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
    if (!$chunks) $chunks = [$text];

    foreach ($chunks as $chunk) {
        $data = json_encode(['choices' => [['delta' => ['content' => $chunk]]]]);
        echo "data: $data\n\n";
        ob_flush();
        flush();
        usleep(12000); // 12ms delay for progressive rendering
    }
    echo "data: [DONE]\n\n";
    ob_flush();
    flush();
}

/**
 * Check if Supabase is reachable (quick health check).
 */
function supabaseAvailable(): bool {
    static $cached = null;
    if ($cached !== null) return $cached;

    $ch = curl_init(SUPABASE_URL . '/rest/v1/?select=1');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 3,
        CURLOPT_CONNECTTIMEOUT => 2,
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_PUBLISHABLE_KEY,
            'Authorization: Bearer ' . SUPABASE_PUBLISHABLE_KEY,
        ],
    ]);
    curl_exec($ch);
    $cached = (curl_getinfo($ch, CURLINFO_HTTP_CODE) >= 200 && curl_getinfo($ch, CURLINFO_HTTP_CODE) < 500);
    curl_close($ch);
    return $cached;
}
